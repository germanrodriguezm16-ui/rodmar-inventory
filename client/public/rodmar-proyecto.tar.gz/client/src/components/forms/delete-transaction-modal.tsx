import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { formatCurrency } from "@/lib/calculations";
import type { TransaccionWithSocio } from "@shared/schema";

interface DeleteTransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  transaction: TransaccionWithSocio | null;
}

export default function DeleteTransactionModal({ isOpen, onClose, transaction }: DeleteTransactionModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [confirmDelete, setConfirmDelete] = useState(false);

  const deleteTransactionMutation = useMutation({
    mutationFn: async (transactionToDelete: TransaccionWithSocio) => {
      console.log("=== Deleting transaction:", transactionToDelete.id);
      
      const response = await fetch(`/api/transacciones/${transactionToDelete.id}`, {
        method: "DELETE",
      });

      if (!response.ok) {
        throw new Error(`Error ${response.status}: ${response.statusText}`);
      }

      return response.json();
    },
    onSuccess: () => {
      console.log("=== Transaction deleted successfully");
      toast({
        title: "Transacción eliminada",
        description: "La transacción se eliminó correctamente",
        duration: 2000,
      });

      // INVALIDACIÓN SELECTIVA - Solo entidades afectadas por la transacción eliminada
      console.log("=== INVALIDACIÓN SELECTIVA POST-ELIMINACIÓN ===");
      
      // Siempre invalidar transacciones
      queryClient.invalidateQueries({ queryKey: ["/api/transacciones"] });
      
      // Invalidar solo las entidades que estaban involucradas en la transacción eliminada
      if (transaction?.deQuienTipo === 'mina' || transaction?.paraQuienTipo === 'mina') {
        queryClient.invalidateQueries({ queryKey: ["/api/minas"] });
      }
      if (transaction?.deQuienTipo === 'comprador' || transaction?.paraQuienTipo === 'comprador') {
        queryClient.invalidateQueries({ queryKey: ["/api/compradores"] });
      }
      if (transaction?.deQuienTipo === 'volquetero' || transaction?.paraQuienTipo === 'volquetero') {
        queryClient.invalidateQueries({ queryKey: ["/api/volqueteros"] });
      }
      
      // Solo invalidar viajes si había relación específica (no necesario en la mayoría de casos)
      // queryClient.invalidateQueries({ queryKey: ["/api/viajes"] }); // Comentado para optimización
      
      // Invalidate specific socio queries - manejo seguro para ambos formatos
      if (transaction) {
        // Formato clásico con tipoSocio/socioId
        if (transaction.tipoSocio && transaction.socioId) {
          queryClient.invalidateQueries({ 
            queryKey: ["/api/transacciones", "socio", transaction.tipoSocio, transaction.socioId] 
          });
        }
        // Invalidar queries específicas para LCDM/Postobón
        if (transaction.deQuienTipo === 'lcdm' || transaction.paraQuienTipo === 'lcdm') {
          queryClient.invalidateQueries({ queryKey: ["/api/rodmar-accounts", "lcdm"] });
        }
        if (transaction.deQuienTipo === 'postobon' || transaction.paraQuienTipo === 'postobon') {
          queryClient.invalidateQueries({ queryKey: ["/api/rodmar-accounts", "postobon"] });
        }
      }

      onClose();
    },
    onError: (error: any) => {
      console.error("=== Error deleting transaction:", error);
      toast({
        title: "Error",
        description: error.message || "No se pudo eliminar la transacción",
        variant: "destructive",
        duration: 3000,
      });
    },
  });

  const handleDeleteClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!confirmDelete) {
      setConfirmDelete(true);
      return;
    }

    if (!transaction) {
      console.error("=== No transaction available for deletion");
      toast({
        title: "Error",
        description: "No se pudo identificar la transacción a eliminar",
        variant: "destructive",
        duration: 3000,
      });
      return;
    }
    deleteTransactionMutation.mutate(transaction);
  };

  const handleClose = () => {
    setConfirmDelete(false);
    onClose();
  };

  if (!transaction) return null;

  return (
    <AlertDialog open={isOpen} onOpenChange={handleClose}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>
            {confirmDelete ? "⚠️ Confirmar Eliminación" : "¿Eliminar Transacción?"}
          </AlertDialogTitle>
          <AlertDialogDescription asChild>
            <div className="space-y-3">
              <p>
                {confirmDelete 
                  ? "ATENCIÓN: Esta acción eliminará permanentemente la transacción. ¿Estás completamente seguro?" 
                  : "Esta acción no se puede deshacer. La transacción será eliminada permanentemente."
                }
              </p>
              
              <div className="bg-muted p-4 rounded-lg space-y-2">
                <div className="flex justify-between">
                  <span className="font-medium">Socio:</span>
                  <span>{transaction.socioNombre}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Concepto:</span>
                  <span>{transaction.concepto}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Valor:</span>
                  <span className={`font-semibold ${
                    parseFloat(transaction.valor) >= 0 ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {formatCurrency(transaction.valor)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Fecha:</span>
                  <span>{new Date(transaction.fecha).toLocaleDateString('es-CO')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Forma de Pago:</span>
                  <span>{transaction.formaPago}</span>
                </div>
                {transaction.comentario && (
                  <div className="flex justify-between">
                    <span className="font-medium">Comentario:</span>
                    <span className="text-sm text-muted-foreground max-w-[200px] text-right">
                      {transaction.comentario}
                    </span>
                  </div>
                )}
              </div>
            </div>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel onClick={() => setConfirmDelete(false)}>
            Cancelar
          </AlertDialogCancel>
          <Button
            onClick={handleDeleteClick}
            disabled={deleteTransactionMutation.isPending}
            className={confirmDelete 
              ? "bg-red-600 text-white hover:bg-red-700 font-bold" 
              : "bg-destructive text-destructive-foreground hover:bg-destructive/90"
            }
          >
            {deleteTransactionMutation.isPending 
              ? "Eliminando..." 
              : confirmDelete 
                ? "SÍ, ELIMINAR DEFINITIVAMENTE" 
                : "Eliminar Transacción"
            }
          </Button>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}