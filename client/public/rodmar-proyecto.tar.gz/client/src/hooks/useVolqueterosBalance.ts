import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";

// Función helper que replica la lógica exacta del detalle de volquetero
const calcularBalanceVolquetero = (
  volquetero: any,
  transaccionesData: any[],
  viajes: any[]
) => {
  if (!volquetero) return 0;
  
  // Transacciones manuales - MISMA LÓGICA que volquetero-detail-simple.tsx
  const transaccionesManuales = transaccionesData
    .filter((t: any) => {
      return (t.deQuienTipo === 'volquetero' && t.deQuienId === volquetero.id.toString()) ||
             (t.paraQuienTipo === 'volquetero' && t.paraQuienId === volquetero.id.toString());
    })
    .map((t: any) => {
      const valorFinal = parseFloat(t.valor);
      return {
        id: t.id.toString(),
        concepto: t.concepto,
        valor: valorFinal,
        fecha: t.fecha,
        tipo: "Manual",
        deQuienTipo: t.deQuienTipo,
        deQuienId: t.deQuienId,
        paraQuienTipo: t.paraQuienTipo,
        paraQuienId: t.paraQuienId,
      };
    });

  // Transacciones dinámicas de viajes - MISMA LÓGICA que volquetero-detail-simple.tsx
  const viajesCompletados = viajes
    .filter((v: any) => {
      return v.conductor === volquetero.nombre && 
             v.estado === "completado" && 
             v.fechaDescargue &&
             v.quienPagaFlete !== "comprador" && 
             v.quienPagaFlete !== "El comprador";
    })
    .map((v: any) => {
      const valorFinal = parseFloat(v.totalFlete || "0");
      return {
        id: `viaje-${v.id}`,
        concepto: `Viaje ${v.id} - Flete pagado por RodMar`,
        valor: valorFinal,
        fecha: v.fechaDescargue,
        tipo: "Viaje"
      };
    });

  const todasLasTransacciones = [...transaccionesManuales, ...viajesCompletados];

  // Calcular balance - MISMA LÓGICA que volquetero-detail-simple.tsx
  let ingresos = 0;
  let egresos = 0;
  
  todasLasTransacciones.forEach((t: any) => {
    if (t.tipo === "Manual") {
      // Lógica específica para volqueteros: LÓGICA INVERSA
      if (t.paraQuienTipo === 'volquetero') {
        egresos += Math.abs(t.valor);
      }
      if (t.deQuienTipo === 'volquetero') {
        ingresos += Math.abs(t.valor);
      }
    } else if (t.tipo === "Viaje") {
      // Transacciones de viajes son siempre ingresos
      ingresos += Math.abs(t.valor);
    }
  });
  
  return ingresos - egresos;
};

// Hook compartido para calcular balance de volqueteros
export const useVolqueterosBalance = () => {
  const { data: volqueteros = [] } = useQuery({
    queryKey: ["/api/volqueteros"],
    staleTime: 30000,
  });

  const { data: viajes = [] } = useQuery({
    queryKey: ["/api/viajes"],
    staleTime: 30000,
  });

  const { data: transacciones = [] } = useQuery({
    queryKey: ["/api/transacciones"],
    staleTime: 30000,
  });

  // Calcular balances usando la MISMA LÓGICA EXACTA que el detalle
  const balancesVolqueteros = useMemo(() => {
    const balances: Record<number, number> = {};
    
    if (!Array.isArray(viajes) || !Array.isArray(transacciones) || !Array.isArray(volqueteros)) {
      return balances;
    }

    // Para cada volquetero, calcular balance usando función helper
    volqueteros.forEach((volquetero) => {
      const balanceDetalle = calcularBalanceVolquetero(volquetero, transacciones, viajes);
      
      // USAR MISMO SIGNO que el detalle (sin invertir)
      balances[volquetero.id] = balanceDetalle;
    });
    
    return balances;
  }, [viajes, transacciones, volqueteros]);

  // Calcular resumen financiero general (MISMA LÓGICA QUE volqueteros.tsx)
  const calcularResumenFinanciero = () => {
    let totalPositivos = 0;
    let totalNegativos = 0;

    volqueteros.forEach((volquetero: any) => {
      const balance = balancesVolqueteros[volquetero.id] || 0;
      if (balance > 0) {
        totalPositivos += balance;
      } else if (balance < 0) {
        totalNegativos += Math.abs(balance);
      }
    });

    const balanceNeto = totalPositivos - totalNegativos;

    return {
      positivos: totalPositivos,
      negativos: totalNegativos,
      balance: balanceNeto
    };
  };

  return {
    balancesVolqueteros,
    resumenFinanciero: calcularResumenFinanciero(),
    volqueteros
  };
};