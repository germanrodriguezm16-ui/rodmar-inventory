import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";

// Hook compartido para calcular balance de minas
export const useMinasBalance = () => {
  const { data: minas = [] } = useQuery({
    queryKey: ["/api/minas"],
    staleTime: 30000,
  });

  const { data: allViajes = [] } = useQuery({
    queryKey: ["/api/viajes"],
    staleTime: 30000,
  });

  const { data: allTransacciones = [] } = useQuery({
    queryKey: ["/api/transacciones"],
    staleTime: 30000,
  });

  // Calcular todos los balances de minas (RESTAURADO: usa balanceCalculado como antes)
  const balancesMinas = useMemo(() => {
    const balances: Record<number, number> = {};
    
    (minas as any[]).forEach((mina: any) => {
      if (mina.balanceCalculado !== undefined && mina.balanceCalculado !== null) {
        // RESTAURADO: Usar balance pre-calculado de la base de datos como antes
        balances[mina.id] = parseFloat(mina.balanceCalculado);
      } else {
        // Fallback: cálculo manual si no hay balance calculado (lógica original)
        if (!Array.isArray(allViajes) || !Array.isArray(allTransacciones)) {
          balances[mina.id] = 0;
          return;
        }

        // Lógica original de fallback
        const viajesCompletados = allViajes.filter((v: any) => 
          v.fechaDescargue && v.minaId === mina.id && v.estado === "completado"
        );

        const transaccionesMina = allTransacciones.filter((t: any) => 
          (t.paraQuienTipo === 'mina' && parseInt(t.paraQuienId) === mina.id) ||
          (t.deQuienTipo === 'mina' && parseInt(t.deQuienId) === mina.id)
        );

        // Ingresos por viajes completados (lo que RodMar paga a la mina)
        const ingresosViajes = viajesCompletados.reduce((sum, viaje) => {
          const totalCompra = parseFloat(viaje.totalCompra || '0');
          return sum + totalCompra;
        }, 0);

        // Transacciones netas (solo transacciones manuales, excluyendo viajes)
        const transaccionesNetas = transaccionesMina
          .filter(t => t.tipo !== "Viaje") // Excluir transacciones de viajes
          .reduce((sum, t) => {
            const valor = parseFloat(t.valor || '0');
            if (t.deQuienTipo === 'mina') {
              // Transacciones desde la mina = ingresos positivos (mina vende/recibe)
              return sum + valor;
            } else if (t.paraQuienTipo === 'mina') {
              // Transacciones hacia la mina = egresos negativos
              return sum - valor;
            } else if (t.paraQuienTipo === 'rodmar' || t.paraQuienTipo === 'banco') {
              // Transacciones hacia RodMar/Banco = ingresos positivos
              return sum + valor;
            }
            return sum;
          }, 0);

        balances[mina.id] = ingresosViajes + transaccionesNetas;
      }
    });
    
    return balances;
  }, [minas, allViajes, allTransacciones]);

  // Calcular resumen financiero SINCRONIZADO con RodMar (solo para resumen superior)
  const calcularResumenFinanciero = () => {
    let totalPositivos = 0;
    let totalNegativos = 0;

    (minas as any[]).forEach((mina: any) => {
      // USAR LA MISMA LÓGICA EXACTA QUE calcularBalanceNetoMina de RodMar para el resumen
      if (!Array.isArray(allViajes) || !Array.isArray(allTransacciones)) {
        return;
      }

      const viajesCompletados = allViajes.filter((v: any) => 
        v.fechaDescargue && v.minaId === mina.id && v.estado === "completado"
      );
      
      const transaccionesDinamicas = viajesCompletados.map((viaje: any) => {
        const totalCompra = parseFloat(viaje.totalCompra || "0");
        return {
          valor: totalCompra.toString(),
          isFromTrip: true
        };
      });

      const transaccionesManuales = allTransacciones.filter((t: any) => {
        if (t.paraQuienTipo !== "mina") return false;
        
        const paraQuienIdStr = t.paraQuienId?.toString();
        const minaIdStr = mina.id.toString();
        
        return paraQuienIdStr === minaIdStr;
      }).map((t: any) => ({
        valor: t.valor,
        isFromTrip: false
      }));

      const todasTransacciones = [...transaccionesDinamicas, ...transaccionesManuales];
      
      const balance = todasTransacciones.reduce((balance, transaccion) => {
        const valor = parseFloat(transaccion.valor || "0");
        
        if (transaccion.isFromTrip) {
          return balance + valor;
        } else {
          return balance - Math.abs(valor);
        }
      }, 0);

      // Agregar al resumen
      if (balance > 0) {
        totalPositivos += balance;
      } else if (balance < 0) {
        totalNegativos += Math.abs(balance);
      }
    });

    const balanceNeto = totalPositivos - totalNegativos;

    return {
      positivos: totalPositivos,
      negativos: totalNegativos,
      balance: balanceNeto
    };
  };

  return {
    balancesMinas,
    resumenFinanciero: calcularResumenFinanciero(),
    minas
  };
};