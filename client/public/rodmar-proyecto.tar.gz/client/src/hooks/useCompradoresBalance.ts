import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";

// Hook compartido para calcular balance de compradores
export const useCompradoresBalance = () => {
  const { data: compradores = [] } = useQuery({
    queryKey: ["/api/compradores"],
    staleTime: 30000,
  });

  const { data: allViajes = [] } = useQuery({
    queryKey: ["/api/viajes"],
    staleTime: 30000,
  });

  const { data: allTransacciones = [] } = useQuery({
    queryKey: ["/api/transacciones"],
    staleTime: 30000,
  });

  // Calcular todos los balances de compradores (optimizado con balance pre-calculado)
  const balancesCompradores = useMemo(() => {
    const balances: Record<number, number> = {};
    
    compradores.forEach((comprador: any) => {
      if (comprador.balanceCalculado !== undefined && comprador.balanceCalculado !== null) {
        // Usar balance pre-calculado de la base de datos para mejor rendimiento
        balances[comprador.id] = parseFloat(comprador.balanceCalculado);
      } else {
        // Fallback: cálculo manual si no hay balance calculado (por compatibilidad)
        if (!Array.isArray(allViajes) || !Array.isArray(allTransacciones)) {
          balances[comprador.id] = 0;
          return;
        }

        const viajesCompletados = allViajes.filter((v: any) => 
          v.fechaDescargue && v.compradorId === comprador.id && v.estado === "completado"
        );

        const transaccionesComprador = allTransacciones.filter((t: any) => 
          (t.paraQuienTipo === 'comprador' && parseInt(t.paraQuienId) === comprador.id) ||
          (t.deQuienTipo === 'comprador' && parseInt(t.deQuienId) === comprador.id)
        );

        const totalViajes = viajesCompletados.reduce((sum, viaje) => {
          const valorConsignar = parseFloat(viaje.valorConsignar || "0");
          return sum + valorConsignar;
        }, 0);

        const transaccionesNetas = transaccionesComprador.reduce((sum, transaccion) => {
          const valor = parseFloat(transaccion.valor);
          if (transaccion.deQuienTipo === 'comprador') {
            return sum + valor; // Pago del comprador (reduce deuda)
          } else {
            return sum - valor; // Préstamo al comprador (aumenta deuda)
          }
        }, 0);

        balances[comprador.id] = transaccionesNetas - totalViajes; // Negativo porque totalViajes es deuda
      }
    });
    
    return balances;
  }, [compradores, allViajes, allTransacciones]);

  // Calcular resumen financiero general (MISMA LÓGICA QUE compradores.tsx)
  const calcularResumenFinanciero = () => {
    let totalPositivos = 0;
    let totalNegativos = 0;

    compradores.forEach((comprador: any) => {
      const balance = balancesCompradores[comprador.id] || 0;
      if (balance > 0) {
        totalPositivos += balance;
      } else if (balance < 0) {
        totalNegativos += Math.abs(balance);
      }
    });

    const balanceNeto = totalPositivos - totalNegativos;

    return {
      positivos: totalPositivos,
      negativos: totalNegativos,
      balance: balanceNeto
    };
  };

  return {
    balancesCompradores,
    resumenFinanciero: calcularResumenFinanciero(),
    compradores
  };
};