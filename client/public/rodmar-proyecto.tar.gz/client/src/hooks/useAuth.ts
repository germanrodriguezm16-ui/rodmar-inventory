import { useQuery } from "@tanstack/react-query";

export function useAuth() {
  try {
    const { data: user, isLoading, error } = useQuery({
      queryKey: ["/api/auth/user"],
      queryFn: async () => {
        try {
          const res = await fetch("/api/auth/user", {
            credentials: "include",
          });
          
          if (res.status === 401) {
            return null; // Usuario no autenticado
          }
          
          if (!res.ok) {
            throw new Error(`${res.status}: ${res.statusText}`);
          }
          
          return await res.json();
        } catch (error) {
          console.log("Auth error:", error);
          return null;
        }
      },
      retry: false,
      refetchOnWindowFocus: false,
      staleTime: 5 * 60 * 1000, // 5 minutos
    });

    return {
      user: user || null,
      isLoading: isLoading || false,
      isAuthenticated: !!user,
    };
  } catch (error) {
    console.error("useAuth hook error:", error);
    // Fallback seguro para errores del hook
    return {
      user: null,
      isLoading: false,
      isAuthenticated: false,
    };
  }
}