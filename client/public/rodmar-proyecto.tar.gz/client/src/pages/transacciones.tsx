import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { ArrowLeftRight, Plus, Download, Filter, Edit, Trash2, CheckSquare, Square, CalendarDays, DollarSign, ArrowUp, ArrowDown } from "lucide-react";
// Formateo de fechas se maneja directamente en el componente
import { formatDate } from "@/lib/utils";
import TransactionModal from "@/components/forms/transaction-modal";
import EditTransactionModal from "@/components/forms/edit-transaction-modal";
import DeleteTransactionModal from "@/components/forms/delete-transaction-modal";
import { TransactionDetailModal } from "@/components/modals/transaction-detail-modal";
import BottomNavigation from "@/components/layout/bottom-navigation";

import type { TransaccionWithSocio } from "@shared/schema";

interface TransaccionesProps {
  onOpenTransaction?: () => void;
}

export default function Transacciones({ onOpenTransaction }: TransaccionesProps = {}) {
  console.log('🎯 COMPONENTE TRANSACCIONES (PAGES) - Iniciando render');
  
  const queryClient = useQueryClient();
  const [showAddTransaction, setShowAddTransaction] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [showBulkDeleteModal, setShowBulkDeleteModal] = useState(false);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [selectedTransaction, setSelectedTransaction] = useState<TransaccionWithSocio | null>(null);
  const [selectedTransactions, setSelectedTransactions] = useState<Set<number>>(new Set());
  const [isMultiSelectMode, setIsMultiSelectMode] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");

  const [valorFilterType, setValorFilterType] = useState<string>("todos");
  const [valorFilterValue, setValorFilterValue] = useState("");
  const [valorFilterValueEnd, setValorFilterValueEnd] = useState("");
  const [sortByValor, setSortByValor] = useState<"ninguno" | "asc" | "desc">("ninguno");
  const [sortByFecha, setSortByFecha] = useState<"ninguno" | "asc" | "desc">("desc");
  const [fechaFilterType, setFechaFilterType] = useState<string>("todos");
  const [fechaFilterValue, setFechaFilterValue] = useState("");
  const [fechaFilterValueEnd, setFechaFilterValueEnd] = useState("");

  // Funciones para manejar los tres estados de ordenamiento (ninguno -> asc -> desc -> ninguno)
  const toggleSortFecha = () => {
    const cycle: Array<"ninguno" | "asc" | "desc"> = ["ninguno", "asc", "desc"];
    const currentIndex = cycle.indexOf(sortByFecha);
    const nextIndex = (currentIndex + 1) % cycle.length;
    setSortByFecha(cycle[nextIndex]);
  };

  const toggleSortValor = () => {
    const cycle: Array<"ninguno" | "asc" | "desc"> = ["ninguno", "asc", "desc"];
    const currentIndex = cycle.indexOf(sortByValor);
    const nextIndex = (currentIndex + 1) % cycle.length;
    setSortByValor(cycle[nextIndex]);
  };

  // Función para convertir valor formateado a número
  const parseFormattedValue = (formattedValue: string): string => {
    return formattedValue.replace(/[^\d]/g, '');
  };

  // Función para limpiar conceptos que contienen datos base64
  const cleanConcepto = (concepto: string): string => {
    if (!concepto) return concepto;
    
    // Si el concepto contiene "data:image" o muy largo, lo limpiamos
    if (concepto.includes('data:image') || concepto.includes('#IMAGE') || concepto.length > 150) {
      // Extraer solo la parte descriptiva antes de los datos base64
      const parts = concepto.split(' • ');
      if (parts.length > 0) {
        let cleanPart = parts[0].replace(/\s*#IMAGE.*$/, '').trim();
        // También limpiar si contiene data:image en la parte principal
        cleanPart = cleanPart.replace(/data:image[^,]*,[A-Za-z0-9+/=]+/g, '[Imagen]');
        return cleanPart || 'Transacción con imagen adjunta';
      }
      return 'Transacción con imagen adjunta';
    }
    return concepto;
  };

  // Función para limpiar nombres de socios que contienen datos base64
  const cleanSocioNombre = (nombre: string): string => {
    if (!nombre) return nombre;
    
    // Si el nombre contiene datos base64, limpiarlo
    if (nombre.includes('data:image') || nombre.length > 100) {
      return nombre.replace(/data:image[^,]*,[A-Za-z0-9+/=]+/g, '[Imagen]');
    }
    return nombre;
  };



  const handleEditTransaction = (transaction: TransaccionWithSocio) => {
    setSelectedTransaction(transaction);
    setShowEditModal(true);
  };

  const handleDeleteTransaction = (transaction: TransaccionWithSocio) => {
    setSelectedTransaction(transaction);
    setShowDeleteModal(true);
  };

  const toggleTransactionSelection = (transactionId: number) => {
    setSelectedTransactions(prev => {
      const newSet = new Set(prev);
      if (newSet.has(transactionId)) {
        newSet.delete(transactionId);
      } else {
        newSet.add(transactionId);
      }
      return newSet;
    });
  };

  const toggleSelectAll = () => {
    if (selectedTransactions.size === filteredAndSortedTransactions.length) {
      setSelectedTransactions(new Set());
    } else {
      setSelectedTransactions(new Set(filteredAndSortedTransactions.map(t => t.id)));
    }
  };

  const handleBulkDeleteClick = () => {
    if (selectedTransactions.size === 0) return;
    setShowBulkDeleteModal(true);
  };

  const confirmBulkDelete = async () => {
    try {
      const response = await fetch('/api/transacciones/bulk-delete', {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ids: Array.from(selectedTransactions)
        }),
      });

      if (response.ok) {
        setSelectedTransactions(new Set());
        setIsMultiSelectMode(false);
        setShowBulkDeleteModal(false);
        queryClient.invalidateQueries({ queryKey: ['/api/transacciones'] });
      }
    } catch (error) {
      console.error('Error eliminando transacciones:', error);
    }
  };

  const handleTransactionDetailClick = (transaction: TransaccionWithSocio) => {
    // No abrir modal si está en modo selección múltiple
    if (isMultiSelectMode) return;
    
    setSelectedTransaction(transaction);
    setShowDetailModal(true);
  };

  const { data: transactions = [], isLoading } = useQuery<TransaccionWithSocio[]>({
    queryKey: ["/api/transacciones"],
    staleTime: 30000, // Cache inteligente de 30 segundos para mejor rendimiento
  });
  
  console.log('🏦 TRANSACCIONES (PAGES) - Total recibidas:', transactions.length);
  if (transactions.length > 0) {
    console.log('📅 PRIMERA TRANSACCIÓN - Fecha raw:', transactions[0].fecha);
    console.log('📅 PRIMERA TRANSACCIÓN - Tipo fecha:', typeof transactions[0].fecha);
  }

  // Helper function to get date ranges for filtering
  const getDateRange = (type: string): { start: Date; end: Date } | null => {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    
    switch (type) {
      case "hoy":
        return { start: today, end: new Date(today.getTime() + 24 * 60 * 60 * 1000 - 1) };
      case "ayer":
        const yesterday = new Date(today);
        yesterday.setDate(yesterday.getDate() - 1);
        return { start: yesterday, end: new Date(yesterday.getTime() + 24 * 60 * 60 * 1000 - 1) };
      case "esta-semana":
        const startOfWeek = new Date(today);
        startOfWeek.setDate(today.getDate() - today.getDay());
        return { start: startOfWeek, end: now };
      case "semana-pasada":
        const startOfLastWeek = new Date(today);
        startOfLastWeek.setDate(today.getDate() - today.getDay() - 7);
        const endOfLastWeek = new Date(startOfLastWeek);
        endOfLastWeek.setDate(startOfLastWeek.getDate() + 6);
        endOfLastWeek.setHours(23, 59, 59, 999);
        return { start: startOfLastWeek, end: endOfLastWeek };
      case "este-mes":
        const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
        return { start: startOfMonth, end: now };
      case "mes-pasado":
        const startOfLastMonth = new Date(today.getFullYear(), today.getMonth() - 1, 1);
        const endOfLastMonth = new Date(today.getFullYear(), today.getMonth(), 0);
        endOfLastMonth.setHours(23, 59, 59, 999);
        return { start: startOfLastMonth, end: endOfLastMonth };
      case "este-año":
        const startOfYear = new Date(today.getFullYear(), 0, 1);
        return { start: startOfYear, end: now };
      case "año-pasado":
        const startOfLastYear = new Date(today.getFullYear() - 1, 0, 1);
        const endOfLastYear = new Date(today.getFullYear() - 1, 11, 31);
        endOfLastYear.setHours(23, 59, 59, 999);
        return { start: startOfLastYear, end: endOfLastYear };
      default:
        return null;
    }
  };

  // Fetch entities for name resolution
  const { data: minas = [] } = useQuery<{id: number, nombre: string}[]>({
    queryKey: ["/api/minas"],
    staleTime: 30000,
  });

  const { data: compradores = [] } = useQuery<{id: number, nombre: string}[]>({
    queryKey: ["/api/compradores"],
    staleTime: 30000,
  });

  const { data: volqueteros = [] } = useQuery<{id: number, nombre: string}[]>({
    queryKey: ["/api/volqueteros"],
    staleTime: 30000,
  });

  // Lazy loading: solo cargar viajes cuando hay transacciones tipo "Viaje" seleccionadas
  // En este módulo normalmente no hay transacciones tipo "Viaje", pero mantenemos por compatibilidad
  const needsViajesData = selectedTransaction?.tipoTransaccion === "Viaje";
  const { data: viajes = [] } = useQuery<any[]>({
    queryKey: ["/api/viajes"],
    staleTime: 30000,
    enabled: needsViajesData, // Solo ejecutar cuando se necesite realmente
  });



  const formatCurrency = (amount: string | number) => {
    const numAmount = typeof amount === 'string' ? parseFloat(amount) : amount;
    return new Intl.NumberFormat('es-CO', {
      style: 'currency',
      currency: 'COP',
      minimumFractionDigits: 0,
    }).format(numAmount);
  };

  // Función para calcular el valor de visualización considerando la lógica de colores
  const getDisplayValue = (transaction: any) => {
    let valor = parseFloat(transaction.valor);
    
    // LÓGICA DE CODIFICACIÓN DE COLORES UNIFICADA:
    // 1. Transacciones desde mina/comprador/volquetero = Verde y positivo  
    // 2. Transacciones RodMar a RodMar = Azul y no afecta balance (neutral)
    
    const isFromPartner = transaction.deQuienTipo === 'mina' || 
                         transaction.deQuienTipo === 'comprador' || 
                         transaction.deQuienTipo === 'volquetero';
    
    const isRodMarToRodMar = transaction.deQuienTipo === 'rodmar' && transaction.paraQuienTipo === 'rodmar';
    
    if (isFromPartner) {
      // Regla 1: Origen desde socios = valor positivo (verde)
      valor = Math.abs(valor);
    } else if (isRodMarToRodMar) {
      // Regla 2: RodMar a RodMar = neutral (0) para no afectar ordenamiento/balance
      valor = 0;
    } else {
      // Lógica anterior para otros casos
      if (transaction.paraQuienTipo) {
        const isToPartner = transaction.paraQuienTipo === 'mina' || 
                          transaction.paraQuienTipo === 'comprador' || 
                          transaction.paraQuienTipo === 'volquetero';
        const isToBanco = transaction.paraQuienTipo === 'banco';
        
        if (isToPartner || isToBanco) {
          // Destino hacia socios o banco = valor negativo (rojo)
          valor = -Math.abs(valor);
        } else {
          // Destino hacia RodMar = valor positivo (verde)
          valor = Math.abs(valor);
        }
      } else if (transaction.deQuienTipo === 'rodmar') {
        // Origen desde RodMar = valor negativo (rojo)
        valor = -Math.abs(valor);
      }
    }
    
    return valor;
  };

  const filteredAndSortedTransactions = (() => {
    // Primero aplicar filtros
    let filtered = transactions.filter(transaction => {

      const matchesSearch = !searchTerm || 
        transaction.socioNombre?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        transaction.concepto.toLowerCase().includes(searchTerm.toLowerCase()) ||
        transaction.voucher?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        transaction.comentario?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        // Buscar en fecha usando formato sin iniciales de día (DD/MM/YYYY)
        formatDate(transaction.fecha).toLowerCase().includes(searchTerm.toLowerCase());
      
      // Filtro por valor (considerando valores negativos/positivos según lógica de colores)
      let matchesValor = true;
      if (valorFilterType && valorFilterType !== "todos" && valorFilterValue) {
        const transactionDisplayValue = getDisplayValue(transaction); // Usa la lógica de colores para determinar el valor real
        const filterValue = parseFloat(valorFilterValue);
        
        switch (valorFilterType) {
          case "exactamente":
            matchesValor = Math.abs(transactionDisplayValue) === Math.abs(filterValue);
            break;
          case "mayor":
            matchesValor = transactionDisplayValue > filterValue;
            break;
          case "menor":
            matchesValor = transactionDisplayValue < filterValue;
            break;
          case "entre":
            const filterValueEnd = parseFloat(valorFilterValueEnd || "0");
            matchesValor = transactionDisplayValue >= filterValue && transactionDisplayValue <= filterValueEnd;
            break;
          default:
            matchesValor = true;
        }
      }

      // Filter by date using string comparison to avoid UTC issues (método exitoso migrado desde compradores y minas)
      let matchesFecha = true;
      if (fechaFilterType && fechaFilterType !== "todos") {
        // Extraer fecha directamente del string para evitar conversiones UTC problemáticas
        const fechaString = String(transaction.fecha);
        const fechaDirecta = transaction.fecha instanceof Date 
          ? transaction.fecha.toISOString().split('T')[0]
          : fechaString.includes('T') 
              ? fechaString.split('T')[0] 
              : fechaString;

        // Para filtros con valores específicos de fecha
        if (fechaFilterType === "exactamente" && fechaFilterValue) {
          matchesFecha = fechaDirecta === fechaFilterValue;
        } else if (fechaFilterType === "entre" && fechaFilterValue && fechaFilterValueEnd) {
          matchesFecha = fechaDirecta >= fechaFilterValue && fechaDirecta <= fechaFilterValueEnd;
        } else if (fechaFilterType === "despues-de" && fechaFilterValue) {
          matchesFecha = fechaDirecta > fechaFilterValue;
        } else if (fechaFilterType === "antes-de" && fechaFilterValue) {
          matchesFecha = fechaDirecta < fechaFilterValue;
        } else {
          // Para filtros preestablecidos - generar fechas como strings directamente  
          const now = new Date();
          const hoyString = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
          
          switch (fechaFilterType) {
            case "hoy": {
              matchesFecha = fechaDirecta === hoyString;
              break;
            }
            case "ayer": {
              const ayer = new Date(now);
              ayer.setDate(ayer.getDate() - 1);
              const ayerString = `${ayer.getFullYear()}-${String(ayer.getMonth() + 1).padStart(2, '0')}-${String(ayer.getDate()).padStart(2, '0')}`;
              matchesFecha = fechaDirecta === ayerString;
              break;
            }
            case "esta-semana": {
              const inicioSemana = new Date(now);
              inicioSemana.setDate(now.getDate() - now.getDay());
              const inicioSemanaString = `${inicioSemana.getFullYear()}-${String(inicioSemana.getMonth() + 1).padStart(2, '0')}-${String(inicioSemana.getDate()).padStart(2, '0')}`;
              matchesFecha = fechaDirecta >= inicioSemanaString && fechaDirecta <= hoyString;
              break;
            }
            case "semana-pasada": {
              const inicioSemanaPasada = new Date(now);
              inicioSemanaPasada.setDate(now.getDate() - now.getDay() - 7);
              const finSemanaPasada = new Date(inicioSemanaPasada);
              finSemanaPasada.setDate(inicioSemanaPasada.getDate() + 6);
              const inicioSemanaPasadaString = `${inicioSemanaPasada.getFullYear()}-${String(inicioSemanaPasada.getMonth() + 1).padStart(2, '0')}-${String(inicioSemanaPasada.getDate()).padStart(2, '0')}`;
              const finSemanaPasadaString = `${finSemanaPasada.getFullYear()}-${String(finSemanaPasada.getMonth() + 1).padStart(2, '0')}-${String(finSemanaPasada.getDate()).padStart(2, '0')}`;
              matchesFecha = fechaDirecta >= inicioSemanaPasadaString && fechaDirecta <= finSemanaPasadaString;
              break;
            }
            case "este-mes": {
              const inicioMes = new Date(now.getFullYear(), now.getMonth(), 1);
              const inicioMesString = `${inicioMes.getFullYear()}-${String(inicioMes.getMonth() + 1).padStart(2, '0')}-${String(inicioMes.getDate()).padStart(2, '0')}`;
              matchesFecha = fechaDirecta >= inicioMesString && fechaDirecta <= hoyString;
              break;
            }
            case "mes-pasado": {
              const inicioMesPasado = new Date(now.getFullYear(), now.getMonth() - 1, 1);
              const finMesPasado = new Date(now.getFullYear(), now.getMonth(), 0);
              const inicioMesPasadoString = `${inicioMesPasado.getFullYear()}-${String(inicioMesPasado.getMonth() + 1).padStart(2, '0')}-${String(inicioMesPasado.getDate()).padStart(2, '0')}`;
              const finMesPasadoString = `${finMesPasado.getFullYear()}-${String(finMesPasado.getMonth() + 1).padStart(2, '0')}-${String(finMesPasado.getDate()).padStart(2, '0')}`;
              matchesFecha = fechaDirecta >= inicioMesPasadoString && fechaDirecta <= finMesPasadoString;
              break;
            }
            case "este-año": {
              const inicioAño = new Date(now.getFullYear(), 0, 1);
              const inicioAñoString = `${inicioAño.getFullYear()}-${String(inicioAño.getMonth() + 1).padStart(2, '0')}-${String(inicioAño.getDate()).padStart(2, '0')}`;
              matchesFecha = fechaDirecta >= inicioAñoString && fechaDirecta <= hoyString;
              break;
            }
            case "año-pasado": {
              const inicioAñoPasado = new Date(now.getFullYear() - 1, 0, 1);
              const finAñoPasado = new Date(now.getFullYear() - 1, 11, 31);
              const inicioAñoPasadoString = `${inicioAñoPasado.getFullYear()}-${String(inicioAñoPasado.getMonth() + 1).padStart(2, '0')}-${String(inicioAñoPasado.getDate()).padStart(2, '0')}`;
              const finAñoPasadoString = `${finAñoPasado.getFullYear()}-${String(finAñoPasado.getMonth() + 1).padStart(2, '0')}-${String(finAñoPasado.getDate()).padStart(2, '0')}`;
              matchesFecha = fechaDirecta >= inicioAñoPasadoString && fechaDirecta <= finAñoPasadoString;
              break;
            }
            default:
              matchesFecha = true;
          }
        }
      }
      
      return matchesSearch && matchesValor && matchesFecha;
    });

    // Luego aplicar ordenamiento por valor si está seleccionado
    if (sortByValor && sortByValor !== "ninguno") {
      filtered = filtered.sort((a, b) => {
        const aValue = getDisplayValue(a);
        const bValue = getDisplayValue(b);
        
        if (sortByValor === "desc") {
          return bValue - aValue; // Mayor a menor (incluye negativos)
        } else if (sortByValor === "asc") {
          return aValue - bValue; // Menor a mayor (incluye negativos)
        }
        return 0;
      });
    }

    // Aplicar ordenamiento por fecha si está seleccionado
    if (sortByFecha && sortByFecha !== "ninguno") {
      filtered = filtered.sort((a, b) => {
        const aDate = new Date(a.fecha);
        const bDate = new Date(b.fecha);
        
        if (sortByFecha === "desc") {
          return bDate.getTime() - aDate.getTime(); // Más reciente primero (fecha mayor)
        } else if (sortByFecha === "asc") {
          return aDate.getTime() - bDate.getTime(); // Más antiguo primero (fecha menor)
        }
        return 0;
      });
    }

    return filtered;
  })();



  const handleExport = () => {
    console.log("Export functionality would go here");
  };

  if (isLoading) {
    return (
      <div className="p-4 space-y-4">
        {Array.from({ length: 3 }).map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-4">
              <div className="h-4 bg-muted rounded mb-2"></div>
              <div className="h-3 bg-muted rounded mb-2"></div>
              <div className="h-3 bg-muted rounded"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-16">
      {/* Filters */}
      <div className="px-4 py-3 bg-card border-b border-border">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-sm font-medium text-foreground">Filtros</h2>
          <Button variant="ghost" size="sm" onClick={() => {
            setSearchTerm("");
            setValorFilterType("todos");
            setValorFilterValue("");
            setValorFilterValueEnd("");
            setSortByValor("ninguno");
            setSortByFecha("ninguno");
            setFechaFilterType("todos");
            setFechaFilterValue("");
            setFechaFilterValueEnd("");
          }}>
            Limpiar
          </Button>
        </div>

        <div className="space-y-2">
          {/* Primera fila: Filtros principales */}
          <div className="grid grid-cols-2 gap-2">
            {/* Filtro de valor */}
            <div>
              <label className="text-xs text-gray-600 mb-1 block">Filtrar por Valor</label>
              <div className="flex gap-1">
                <Select value={valorFilterType} onValueChange={setValorFilterType}>
                  <SelectTrigger className="h-8 text-xs">
                    <SelectValue placeholder="Tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todos">Todos</SelectItem>
                    <SelectItem value="exactamente">Exacto</SelectItem>
                    <SelectItem value="mayor">Mayor</SelectItem>
                    <SelectItem value="menor">Menor</SelectItem>
                    <SelectItem value="entre">Entre</SelectItem>
                  </SelectContent>
                </Select>

                <Input
                  type="text"
                  placeholder="Valor"
                  className="h-8 text-xs"
                  value={valorFilterValue ? formatCurrency(parseFloat(valorFilterValue)) : ''}
                  onChange={(e) => setValorFilterValue(parseFormattedValue(e.target.value))}
                  disabled={!valorFilterType || valorFilterType === "todos"}
                />

                {valorFilterType === "entre" && (
                  <Input
                    type="text"
                    placeholder="Final"
                    className="h-8 text-xs"
                    value={valorFilterValueEnd ? formatCurrency(parseFloat(valorFilterValueEnd)) : ''}
                    onChange={(e) => setValorFilterValueEnd(parseFormattedValue(e.target.value))}
                  />
                )}
              </div>
            </div>

            {/* Búsqueda */}
            <div>
              <label className="text-xs text-gray-600 mb-1 block">Búsqueda Global</label>
              <Input
                placeholder="Nombre, concepto, voucher..."
                className="h-8 text-xs"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>

          {/* Segunda fila: Filtro de fecha y botones de ordenamiento */}
          <div className="flex items-end gap-2">
            {/* Filtro de fecha */}
            <div className="flex-1">
              <label className="text-xs text-gray-600 mb-1 block">Filtrar por Fecha</label>
              <div className="flex gap-1">
                <Select value={fechaFilterType} onValueChange={setFechaFilterType}>
                  <SelectTrigger className="h-8 text-xs">
                    <SelectValue placeholder="Período" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todos">Todas</SelectItem>
                    <SelectItem value="exactamente">Exactamente</SelectItem>
                    <SelectItem value="entre">Entre</SelectItem>
                    <SelectItem value="despues-de">Después de</SelectItem>
                    <SelectItem value="antes-de">Antes de</SelectItem>
                    <SelectItem value="hoy">Hoy</SelectItem>
                    <SelectItem value="ayer">Ayer</SelectItem>
                    <SelectItem value="esta-semana">Esta semana</SelectItem>
                    <SelectItem value="semana-pasada">Semana pasada</SelectItem>
                    <SelectItem value="este-mes">Este mes</SelectItem>
                    <SelectItem value="mes-pasado">Mes pasado</SelectItem>
                    <SelectItem value="este-año">Este año</SelectItem>
                    <SelectItem value="año-pasado">Año pasado</SelectItem>
                  </SelectContent>
                </Select>

                {(fechaFilterType === "exactamente" || fechaFilterType === "despues-de" || fechaFilterType === "antes-de") && (
                  <Input
                    type="date"
                    className="h-8 text-xs"
                    value={fechaFilterValue}
                    onChange={(e) => setFechaFilterValue(e.target.value)}
                  />
                )}

                {fechaFilterType === "entre" && (
                  <>
                    <Input
                      type="date"
                      placeholder="Desde"
                      className="h-8 text-xs"
                      value={fechaFilterValue}
                      onChange={(e) => setFechaFilterValue(e.target.value)}
                    />
                    <Input
                      type="date"
                      placeholder="Hasta"
                      className="h-8 text-xs"
                      value={fechaFilterValueEnd}
                      onChange={(e) => setFechaFilterValueEnd(e.target.value)}
                    />
                  </>
                )}
              </div>
            </div>

            {/* Botones de ordenamiento compactos */}
            <div className="flex items-center space-x-1">
              <span className="text-xs text-gray-600">Orden:</span>
              
              {/* Botón ordenamiento por fecha */}
              <Button
                variant="ghost"
                size="sm"
                onClick={toggleSortFecha}
                className={`h-8 px-2 flex items-center space-x-1 ${
                  sortByFecha !== "ninguno" 
                    ? "bg-blue-100 hover:bg-blue-200 text-blue-700" 
                    : "text-gray-500"
                }`}
                title={
                  sortByFecha === "ninguno" ? "Sin orden por fecha" :
                  sortByFecha === "asc" ? "Más antiguo primero" : 
                  "Más reciente primero"
                }
              >
                <CalendarDays className="w-3 h-3" />
                {sortByFecha === "ninguno" && <span className="text-xs">-</span>}
                {sortByFecha === "asc" && <ArrowUp className="w-3 h-3" />}
                {sortByFecha === "desc" && <ArrowDown className="w-3 h-3" />}
              </Button>

              {/* Botón ordenamiento por valor */}
              <Button
                variant="ghost"
                size="sm"
                onClick={toggleSortValor}
                className={`h-8 px-2 flex items-center space-x-1 ${
                  sortByValor !== "ninguno" 
                    ? "bg-green-100 hover:bg-green-200 text-green-700" 
                    : "text-gray-500"
                }`}
                title={
                  sortByValor === "ninguno" ? "Sin orden por valor" :
                  sortByValor === "asc" ? "Menor a mayor" : 
                  "Mayor a menor"
                }
              >
                <DollarSign className="w-3 h-3" />
                {sortByValor === "ninguno" && <span className="text-xs">-</span>}
                {sortByValor === "asc" && <ArrowUp className="w-3 h-3" />}
                {sortByValor === "desc" && <ArrowDown className="w-3 h-3" />}
              </Button>
            </div>
          </div>

        </div>
      </div>

      {/* Resumen Financiero */}
      <div className="px-4 py-3 bg-card border-b border-border">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-base font-medium text-foreground">Transacciones</h2>
          <span className="text-sm bg-muted px-2 py-1 rounded-full">
            {filteredAndSortedTransactions.length}
          </span>
        </div>
        
        {/* Balance General */}
        <div className="flex items-center justify-between text-sm space-x-4">
          <div className="flex items-center space-x-4">
            <div>
              <span className="text-muted-foreground">Positivos: </span>
              <span className="text-green-600 font-medium">{formatCurrency((() => {
                let total = 0;
                filteredAndSortedTransactions.forEach((t) => {
                  // NUEVAS REGLAS: Positivos incluyen transacciones desde socios y hacia RodMar solamente
                  // (excluyendo RodMar a RodMar que no afecta balance y excluyendo hacia Banco que ahora es negativo)
                  const isFromPartner = t.deQuienTipo === 'mina' || 
                                       t.deQuienTipo === 'comprador' || 
                                       t.deQuienTipo === 'volquetero';
                  
                  const isToRodMar = t.paraQuienTipo === 'rodmar';
                  const isRodMarToRodMar = t.deQuienTipo === 'rodmar' && t.paraQuienTipo === 'rodmar';
                  
                  if (isFromPartner || (isToRodMar && !isRodMarToRodMar)) {
                    total += Math.abs(parseFloat(t.valor));
                  }
                });
                return total;
              })().toString())}</span>
            </div>
            <div>
              <span className="text-muted-foreground">Negativos: </span>
              <span className="text-red-600 font-medium">{formatCurrency((() => {
                let total = 0;
                filteredAndSortedTransactions.forEach((t) => {
                  // NUEVAS REGLAS: Negativos son transacciones hacia socios y hacia banco (excluyendo desde socios y RodMar a RodMar)
                  const isFromPartner = t.deQuienTipo === 'mina' || 
                                       t.deQuienTipo === 'comprador' || 
                                       t.deQuienTipo === 'volquetero';
                  
                  const isToPartner = t.paraQuienTipo === 'mina' || 
                                    t.paraQuienTipo === 'comprador' || 
                                    t.paraQuienTipo === 'volquetero';
                  
                  const isToBanco = t.paraQuienTipo === 'banco';
                  const isRodMarToRodMar = t.deQuienTipo === 'rodmar' && t.paraQuienTipo === 'rodmar';
                  
                  // Solo contar como negativo si NO es desde socio y NO es RodMar a RodMar
                  if ((isToPartner || isToBanco) && !isFromPartner && !isRodMarToRodMar) {
                    total += Math.abs(parseFloat(t.valor));
                  }
                });
                return total;
              })().toString())}</span>
            </div>
            <div>
              <span className="text-muted-foreground">Balance: </span>
              <span className={`font-medium ${
                (() => {
                  let balance = 0;
                  filteredAndSortedTransactions.forEach((t) => {
                    // NUEVAS REGLAS PARA CLASE CSS:
                    // 1. Transacciones desde socios = positivo
                    // 2. Transacciones RodMar a RodMar = excluidas del balance
                    // 3. Resto siguen lógica anterior
                    
                    const isFromPartner = t.deQuienTipo === 'mina' || 
                                         t.deQuienTipo === 'comprador' || 
                                         t.deQuienTipo === 'volquetero';
                    
                    const isRodMarToRodMar = t.deQuienTipo === 'rodmar' && t.paraQuienTipo === 'rodmar';
                    
                    // Excluir RodMar a RodMar del balance
                    if (isRodMarToRodMar) {
                      return; // No afecta balance
                    }
                    
                    const valor = Math.abs(parseFloat(t.valor));
                    
                    if (isFromPartner) {
                      balance += valor; // Positivo para origen desde socios
                    } else {
                      // Lógica anterior para otros casos
                      const isToRodMar = t.paraQuienTipo === 'rodmar';
                      const isToBanco = t.paraQuienTipo === 'banco';
                      const isToPartner = t.paraQuienTipo === 'mina' || 
                                        t.paraQuienTipo === 'comprador' || 
                                        t.paraQuienTipo === 'volquetero';
                      
                      if (isToRodMar) {
                        balance += valor; // Positivo para destino RodMar
                      } else if (isToPartner || isToBanco) {
                        balance -= valor; // Negativo para destino socios o banco
                      }
                    }
                  });
                  return balance > 0 ? 'text-green-600' : balance < 0 ? 'text-red-600' : 'text-gray-600';
                })()
              }`}>
                {formatCurrency((() => {
                  let balance = 0;
                  filteredAndSortedTransactions.forEach((t) => {
                    // NUEVAS REGLAS DE BALANCE:
                    // 1. Transacciones desde socios = positivo
                    // 2. Transacciones RodMar a RodMar = no afecta balance (excluidas)
                    // 3. Resto siguen lógica anterior
                    
                    const isFromPartner = t.deQuienTipo === 'mina' || 
                                         t.deQuienTipo === 'comprador' || 
                                         t.deQuienTipo === 'volquetero';
                    
                    const isRodMarToRodMar = t.deQuienTipo === 'rodmar' && t.paraQuienTipo === 'rodmar';
                    
                    // Excluir RodMar a RodMar del balance
                    if (isRodMarToRodMar) {
                      return; // No afecta balance
                    }
                    
                    const valor = Math.abs(parseFloat(t.valor));
                    
                    if (isFromPartner) {
                      balance += valor; // Positivo para origen desde socios
                    } else {
                      // Lógica anterior para otros casos
                      const isToRodMar = t.paraQuienTipo === 'rodmar';
                      const isToBanco = t.paraQuienTipo === 'banco';
                      const isToPartner = t.paraQuienTipo === 'mina' || 
                                        t.paraQuienTipo === 'comprador' || 
                                        t.paraQuienTipo === 'volquetero';
                      
                      if (isToRodMar) {
                        balance += valor; // Positivo para destino RodMar
                      } else if (isToPartner || isToBanco) {
                        balance -= valor; // Negativo para destino socios o banco
                      }
                    }
                  });
                  return balance;
                })().toString())}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Transactions List */}
      <div className="px-4 py-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            {isMultiSelectMode && selectedTransactions.size > 0 && (
              <Badge variant="secondary" className="text-xs">
                {selectedTransactions.size} seleccionadas
              </Badge>
            )}
          </div>
          <div className="flex items-center space-x-2">
            {isMultiSelectMode && selectedTransactions.size > 0 && (
              <Button
                variant="destructive"
                size="sm"
                onClick={handleBulkDeleteClick}
                className="h-8 text-xs"
              >
                <Trash2 className="h-3 w-3 mr-1" />
                Eliminar ({selectedTransactions.size})
              </Button>
            )}
            <Button
              variant={isMultiSelectMode ? "default" : "ghost"}
              size="sm"
              onClick={() => {
                setIsMultiSelectMode(!isMultiSelectMode);
                setSelectedTransactions(new Set());
              }}
              className="h-8 text-xs"
            >
              {isMultiSelectMode ? "Cancelar" : "Seleccionar"}
            </Button>
            <Button variant="ghost" size="icon" onClick={handleExport}>
              <Download className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {filteredAndSortedTransactions.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <ArrowLeftRight className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground mb-4">No se encontraron transacciones</p>
              <Button onClick={() => setShowAddTransaction(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Registrar Transacción
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-3">
            {/* Header de selección múltiple */}
            {isMultiSelectMode && (
              <Card className="bg-blue-50 border-blue-200">
                <CardContent className="p-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={toggleSelectAll}
                        className="h-8 w-8 p-0"
                      >
                        {selectedTransactions.size === filteredAndSortedTransactions.length && filteredAndSortedTransactions.length > 0 ? 
                          <CheckSquare className="h-4 w-4" /> : 
                          <Square className="h-4 w-4" />
                        }
                      </Button>
                      <span className="text-sm font-medium">
                        {selectedTransactions.size} de {filteredAndSortedTransactions.length} seleccionadas
                      </span>
                    </div>
                    {selectedTransactions.size > 0 && (
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={handleBulkDeleteClick}
                        className="h-8"
                      >
                        <Trash2 className="h-4 w-4 mr-1" />
                        Eliminar ({selectedTransactions.size})
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Lista de transacciones en formato de tarjetas */}
            {filteredAndSortedTransactions.map((transaction) => (
              <Card 
                key={transaction.id} 
                className="hover:shadow-sm transition-shadow cursor-pointer hover:bg-gray-50"
                onClick={() => handleTransactionDetailClick(transaction)}
              >
                <CardContent className="p-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3 flex-1">
                      {/* Checkbox de selección múltiple */}
                      {isMultiSelectMode && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleTransactionSelection(transaction.id);
                          }}
                          className="h-6 w-6 p-0 mt-1"
                        >
                          {selectedTransactions.has(transaction.id) ? 
                            <CheckSquare className="h-4 w-4" /> : 
                            <Square className="h-4 w-4" />
                          }
                        </Button>
                      )}

                      <div className="flex-1 min-w-0">
                        {/* Header compacto */}
                        <div className="flex items-center gap-2 mb-1">
                          <Badge variant="outline" className="text-xs px-1 py-0 h-5 shrink-0">
                            {transaction.deQuienTipo === 'mina' ? 'Mina' : 
                             transaction.deQuienTipo === 'comprador' ? 'Comprador' : 
                             transaction.deQuienTipo === 'volquetero' ? 'Volquetero' : 
                             transaction.deQuienTipo === 'rodmar' ? 'RodMar' : 'Banco'}
                          </Badge>
                          <span className="text-sm font-medium text-foreground truncate">
                            {cleanSocioNombre(transaction.socioNombre || transaction.concepto)}
                          </span>
                        </div>
                        
                        {/* Concepto */}
                        <p className="text-sm text-muted-foreground mb-1 line-clamp-1">
                          {cleanConcepto(transaction.concepto)}
                        </p>
                        
                        {/* Información inferior compacta */}
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <span>{(() => {
                            // Formateo simple de fecha para evitar problemas UTC
                            const fecha = transaction.fecha;
                            const fechaString = String(fecha);
                            if (typeof fecha === 'string' || fecha instanceof Date) {
                              // Si es string, extraer solo fecha (YYYY-MM-DD)
                              const dateStr = fechaString.includes('T') ? fechaString.split('T')[0] : fechaString;
                              const [year, month, day] = dateStr.split('-');
                              return `${day}/${month}/${year?.slice(-2) || ''}`;
                            } else if (fecha instanceof Date) {
                              // Si es Date, extraer componentes locales
                              const fechaObj = fecha as Date;
                              const day = String(fechaObj.getDate()).padStart(2, '0');
                              const month = String(fechaObj.getMonth() + 1).padStart(2, '0');
                              const year = String(fechaObj.getFullYear()).slice(-2);
                              return `${day}/${month}/${year}`;
                            }
                            return 'Fecha inválida';
                          })()}</span>
                          <span>•</span>
                          <span className="truncate">{transaction.formaPago}</span>
                        </div>
                      </div>
                    </div>
                    
                    {/* Valor y Acciones */}
                    <div className="flex flex-col items-end ml-3 shrink-0 gap-1">
                      <div className={`text-base font-semibold ${(() => {
                        // NUEVAS REGLAS DE CODIFICACIÓN DE COLORES:
                        // 1. Transacciones desde mina/comprador/volquetero = Verde y positivo  
                        // 2. Transacciones RodMar a RodMar = Azul y no afecta balance
                        
                        const isFromPartner = transaction.deQuienTipo === 'mina' || 
                                             transaction.deQuienTipo === 'comprador' || 
                                             transaction.deQuienTipo === 'volquetero';
                        
                        const isRodMarToRodMar = transaction.deQuienTipo === 'rodmar' && transaction.paraQuienTipo === 'rodmar';
                        
                        if (isFromPartner) {
                          return 'text-green-600'; // VERDE para origen desde socios
                        } else if (isRodMarToRodMar) {
                          return 'text-blue-600'; // AZUL para RodMar a RodMar
                        } else {
                          // Lógica anterior para otros casos
                          const isToPartner = transaction.paraQuienTipo === 'mina' || 
                                            transaction.paraQuienTipo === 'comprador' || 
                                            transaction.paraQuienTipo === 'volquetero';
                          const isToBanco = transaction.paraQuienTipo === 'banco';
                          const isToRodMar = transaction.paraQuienTipo === 'rodmar';
                          
                          if (isToPartner || isToBanco) {
                            return 'text-red-600'; // ROJO para destino socios o banco
                          } else if (isToRodMar) {
                            return 'text-green-600'; // VERDE para destino RodMar
                          } else {
                            return 'text-gray-600';
                          }
                        }
                      })()}`}>
                        {(() => {
                          // NUEVAS REGLAS DE VISUALIZACIÓN DE VALORES:
                          // 1. Transacciones desde mina/comprador/volquetero = positivo  
                          // 2. Transacciones RodMar a RodMar = positivo (sin signo especial)
                          
                          const isFromPartner = transaction.deQuienTipo === 'mina' || 
                                               transaction.deQuienTipo === 'comprador' || 
                                               transaction.deQuienTipo === 'volquetero';
                          
                          const isRodMarToRodMar = transaction.deQuienTipo === 'rodmar' && transaction.paraQuienTipo === 'rodmar';
                          
                          let displayValue = parseFloat(transaction.valor);
                          
                          if (isFromPartner) {
                            displayValue = Math.abs(displayValue); // Positivo para origen desde socios
                          } else if (isRodMarToRodMar) {
                            displayValue = Math.abs(displayValue); // Positivo (neutro) para RodMar a RodMar
                          } else {
                            // Lógica anterior para otros casos
                            const isToPartner = transaction.paraQuienTipo === 'mina' || 
                                              transaction.paraQuienTipo === 'comprador' || 
                                              transaction.paraQuienTipo === 'volquetero';
                            
                            if (isToPartner) {
                              displayValue = -Math.abs(displayValue); // Negativo para destino socios
                            } else {
                              displayValue = Math.abs(displayValue); // Positivo para destino RodMar/Banco
                            }
                          }
                          
                          return formatCurrency(displayValue.toString());
                        })()}
                      </div>
                      
                      {/* Botones de acciones */}
                      <div className="flex gap-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-6 w-6 p-0"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleEditTransaction(transaction);
                          }}
                          title="Editar transacción"
                        >
                          <Edit className="h-3 w-3" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-6 w-6 p-0 text-red-500 hover:text-red-700"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteTransaction(transaction);
                          }}
                          title="Eliminar transacción"
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  </div>
                  
                  {/* Comentario si existe */}
                  {transaction.comentario && (
                    <p className="text-xs text-muted-foreground border-t pt-2 mt-2 line-clamp-2">
                      {transaction.comentario}
                    </p>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}


      </div>

      <TransactionModal 
        open={showAddTransaction} 
        onClose={() => setShowAddTransaction(false)}
      />
      
      <EditTransactionModal
        isOpen={showEditModal}
        onClose={() => {
          setShowEditModal(false);
          setSelectedTransaction(null);
        }}
        transaction={selectedTransaction}
      />
      
      <DeleteTransactionModal
        isOpen={showDeleteModal}
        onClose={() => {
          setShowDeleteModal(false);
          setSelectedTransaction(null);
        }}
        transaction={selectedTransaction}
      />

      {/* Modal de detalle de transacción */}
      <TransactionDetailModal
        open={showDetailModal}
        onOpenChange={setShowDetailModal}
        transaction={selectedTransaction}
        relatedTrip={(() => {
          // Solo para transacciones automáticas de viajes (tipoTransaccion: "Viaje"), no para transacciones manuales
          if (selectedTransaction?.tipoTransaccion === "Viaje" && selectedTransaction?.concepto) {
            const viajeId = selectedTransaction.concepto.match(/Viaje\s+([A-Z]\d+)/i)?.[1];
            if (viajeId) {
              return viajes.find(v => v.id === viajeId);
            }
          }
          return null;
        })()}
      />

      {/* Modal de confirmación para eliminación masiva */}
      <AlertDialog open={showBulkDeleteModal} onOpenChange={setShowBulkDeleteModal}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Eliminar transacciones seleccionadas?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta acción no se puede deshacer. Se eliminarán permanentemente {selectedTransactions.size} transacciones seleccionadas.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmBulkDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Eliminar {selectedTransactions.size} transacciones
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Navegación inferior fija */}
      <BottomNavigation />
    </div>
  );
}
