import { 
  type User, type UpsertUser,
  type Mina, type InsertMina,
  type Comprador, type InsertComprador,
  type Volquetero, type InsertVolquetero,
  type Viaje, type InsertViaje, type UpdateViaje, type ViajeWithDetails,
  type Transaccion, type InsertTransaccion, type TransaccionWithSocio,
  type VolqueteroConPlacas
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  upsertUser(userData: UpsertUser): Promise<User>;

  // Minas
  getMinas(userId?: string): Promise<Mina[]>;
  getMinaById(id: number, userId?: string): Promise<Mina | undefined>;
  createMina(mina: InsertMina & { userId?: string }): Promise<Mina>;
  updateMina(id: number, updates: Partial<InsertMina>, userId?: string): Promise<Mina | undefined>;
  deleteMina(id: number, userId?: string): Promise<boolean>;

  // Compradores
  getCompradores(userId?: string): Promise<Comprador[]>;
  getCompradorById(id: number, userId?: string): Promise<Comprador | undefined>;
  createComprador(comprador: InsertComprador & { userId?: string }): Promise<Comprador>;
  updateComprador(id: number, updates: Partial<InsertComprador>, userId?: string): Promise<Comprador | undefined>;
  deleteComprador(id: number, userId?: string): Promise<boolean>;

  // Volqueteros
  getVolqueteros(userId?: string): Promise<Volquetero[]>;
  getVolqueteroById(id: number, userId?: string): Promise<Volquetero | undefined>;
  createVolquetero(volquetero: InsertVolquetero & { userId?: string }): Promise<Volquetero>;
  updateVolquetero(id: number, updates: Partial<InsertVolquetero>, userId?: string): Promise<Volquetero | undefined>;
  deleteVolquetero(id: number, userId?: string): Promise<boolean>;

  // Viajes
  getViajes(userId?: string): Promise<ViajeWithDetails[]>;
  getViajeById(id: string, userId?: string): Promise<ViajeWithDetails | undefined>;
  createViaje(viaje: InsertViaje & { userId?: string }): Promise<Viaje>;
  updateViaje(id: string, updates: UpdateViaje, userId?: string): Promise<Viaje | undefined>;
  deleteViaje(id: string, userId?: string): Promise<boolean>;
  getViajesByMina(minaId: number, userId?: string): Promise<ViajeWithDetails[]>;
  getViajesByComprador(compradorId: number, userId?: string): Promise<ViajeWithDetails[]>;
  getViajesByVolquetero(conductor: string, userId?: string): Promise<ViajeWithDetails[]>;

  // Transacciones
  getTransacciones(userId?: string): Promise<TransaccionWithSocio[]>;
  getTransaccionById(id: number, userId?: string): Promise<Transaccion | undefined>;
  createTransaccion(transaccion: InsertTransaccion & { userId?: string }): Promise<Transaccion>;
  updateTransaccion(id: number, updates: Partial<InsertTransaccion>, userId?: string): Promise<Transaccion | undefined>;
  deleteTransaccion(id: number, userId?: string): Promise<boolean>;
  getTransaccionesBySocio(tipoSocio: string, socioId: number, userId?: string): Promise<TransaccionWithSocio[]>;

  // Application specific
  getVolqueterosWithPlacas(userId?: string): Promise<VolqueteroConPlacas[]>;
  bulkImportViajes(viajesData: any[], userId?: string): Promise<Viaje[]>;
  cleanDuplicates(): Promise<void>;

  // Compatibility methods (for backward compatibility)
  getMina(id: number): Promise<Mina | undefined>;
  getComprador(id: number): Promise<Comprador | undefined>;
  getViaje(id: string): Promise<ViajeWithDetails | undefined>;
  getTransaccion(id: number): Promise<Transaccion | undefined>;
}

// Import DatabaseStorage implementation
import { DatabaseStorage } from "./db-storage";

// Export storage instance using database
export const storage = new DatabaseStorage();