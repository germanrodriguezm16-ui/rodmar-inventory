import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import { initializeDatabase } from "./init-db";
import fs from "fs";
import path from "path";

const app = express();
// Increase payload limit to handle base64 images (50MB limit)
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: false, limit: '50mb' }));

// PWA static files middleware - serve manifest.json with correct content-type and no cache
app.get('/manifest.json', (req, res) => {
  const manifestPath = path.resolve('manifest.json');
  if (fs.existsSync(manifestPath)) {
    res.setHeader('Content-Type', 'application/manifest+json');
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    res.sendFile(manifestPath);
  } else {
    res.status(404).send('Manifest not found');
  }
});

// Serve service worker with no cache
app.get('/sw.js', (req, res) => {
  const swPath = path.resolve('sw.js');
  if (fs.existsSync(swPath)) {
    res.setHeader('Content-Type', 'application/javascript');
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    res.sendFile(swPath);
  } else {
    res.status(404).send('Service Worker not found');
  }
});

// CRITICAL: Serve static RodMar before ANY middleware to avoid React errors
app.get('/rodmar-static', (req, res) => {
  const htmlContent = `
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RodMar - Sistema de Gestión Minera</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
            background: linear-gradient(135deg, #f3f4f6 0%, #e5e7eb 100%);
            min-height: 100vh; padding: 20px;
        }
        .container { max-width: 1200px; margin: 0 auto; }
        .header {
            background: white; border-radius: 12px; padding: 2rem; margin-bottom: 2rem;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1); text-align: center;
        }
        .header h1 { color: #1e40af; font-size: 2.5rem; margin-bottom: 0.5rem; }
        .header p { color: #6b7280; font-size: 1.1rem; }
        .stats-grid {
            display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem; margin-bottom: 2rem;
        }
        .stat-card {
            background: white; border-radius: 12px; padding: 1.5rem;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }
        .stat-card h3 {
            color: #374151; font-size: 0.9rem; font-weight: 600;
            text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 0.5rem;
        }
        .stat-value {
            color: #1f2937; font-size: 2rem; font-weight: bold; margin-bottom: 0.5rem;
        }
        .stat-value.loading { color: #6b7280; font-size: 1rem; }
        .stat-description { color: #6b7280; font-size: 0.9rem; }
        .trips-section {
            background: white; border-radius: 12px; padding: 2rem;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }
        .trips-header {
            display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;
        }
        .trips-header h2 { color: #1f2937; font-size: 1.5rem; }
        .refresh-btn {
            background: #2563eb; color: white; border: none; padding: 0.5rem 1rem;
            border-radius: 6px; cursor: pointer; font-weight: 600;
        }
        .refresh-btn:hover { background: #1d4ed8; }
        .trips-table { width: 100%; border-collapse: collapse; margin-top: 1rem; }
        .trips-table th, .trips-table td {
            padding: 0.75rem; text-align: left; border-bottom: 1px solid #e5e7eb;
        }
        .trips-table th {
            background: #f9fafb; color: #374151; font-weight: 600; font-size: 0.9rem;
            text-transform: uppercase; letter-spacing: 0.05em;
        }
        .status-badge {
            display: inline-block; padding: 0.25rem 0.75rem; border-radius: 9999px;
            font-size: 0.8rem; font-weight: 600;
        }
        .status-completed { background: #dcfce7; color: #166534; }
        .status-pending { background: #fef3c7; color: #92400e; }
        .loading-message { text-align: center; color: #6b7280; padding: 2rem; }
        .error-message {
            text-align: center; color: #dc2626; padding: 2rem; background: #fef2f2;
            border-radius: 6px; margin-top: 1rem;
        }
        @media (max-width: 768px) {
            .header h1 { font-size: 2rem; }
            .stats-grid { grid-template-columns: 1fr; }
            .trips-table { font-size: 0.9rem; }
            .trips-table th, .trips-table td { padding: 0.5rem; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🚛 RodMar</h1>
            <p>Sistema de Gestión de Operaciones Mineras</p>
        </div>
        
        <div class="stats-grid">
            <div class="stat-card">
                <h3>Total Viajes</h3>
                <div class="stat-value loading" id="total-viajes">Cargando...</div>
                <div class="stat-description">Todos los viajes registrados</div>
            </div>
            <div class="stat-card">
                <h3>Minas Activas</h3>
                <div class="stat-value loading" id="total-minas">Cargando...</div>
                <div class="stat-description">Ubicaciones de extracción</div>
            </div>
            <div class="stat-card">
                <h3>Compradores</h3>
                <div class="stat-value loading" id="total-compradores">Cargando...</div>
                <div class="stat-description">Clientes registrados</div>
            </div>
            <div class="stat-card">
                <h3>Estado del Sistema</h3>
                <div class="stat-value" style="color: #16a34a;">✓ Activo</div>
                <div class="stat-description">Funcional sin autenticación</div>
            </div>
        </div>
        
        <div class="trips-section">
            <div class="trips-header">
                <h2>Últimos Viajes</h2>
                <button class="refresh-btn" onclick="loadData()">Actualizar</button>
            </div>
            <div id="trips-content">
                <div class="loading-message">Cargando datos...</div>
            </div>
        </div>
    </div>

    <script>
        let viajesData = [], minasData = [], compradoresData = [];

        async function loadData() {
            try {
                const [viajesRes, minasRes, compradoresRes] = await Promise.all([
                    fetch('/api/viajes'),
                    fetch('/api/minas'),
                    fetch('/api/compradores')
                ]);

                if (viajesRes.ok) {
                    viajesData = await viajesRes.json();
                    document.getElementById('total-viajes').innerHTML = viajesData.length;
                    document.getElementById('total-viajes').classList.remove('loading');
                }

                if (minasRes.ok) {
                    minasData = await minasRes.json();
                    document.getElementById('total-minas').innerHTML = minasData.length;
                    document.getElementById('total-minas').classList.remove('loading');
                }

                if (compradoresRes.ok) {
                    compradoresData = await compradoresRes.json();
                    document.getElementById('total-compradores').innerHTML = compradoresData.length;
                    document.getElementById('total-compradores').classList.remove('loading');
                }

                displayTrips();
            } catch (error) {
                console.error('Error:', error);
                document.getElementById('trips-content').innerHTML = 
                    '<div class="error-message">Error al cargar datos. Verificando conexión...</div>';
            }
        }

        function displayTrips() {
            const tripsContent = document.getElementById('trips-content');
            
            if (!viajesData.length) {
                tripsContent.innerHTML = '<div class="loading-message">No hay viajes registrados</div>';
                return;
            }

            const recentTrips = viajesData.slice(0, 10);
            let tableHTML = \`
                <table class="trips-table">
                    <thead>
                        <tr>
                            <th>ID</th><th>Conductor</th><th>Mina</th><th>Comprador</th>
                            <th>Fecha Cargue</th><th>Estado</th>
                        </tr>
                    </thead>
                    <tbody>
            \`;

            recentTrips.forEach(viaje => {
                const fechaCargue = viaje.fechaCargue ? 
                    new Date(viaje.fechaCargue).toLocaleDateString('es-ES') : '-';
                const status = viaje.fechaDescargue ? 'Completado' : 'Pendiente';
                const statusClass = viaje.fechaDescargue ? 'status-completed' : 'status-pending';
                const mina = minasData.find(m => m.id === viaje.minaId);
                const comprador = compradoresData.find(c => c.id === viaje.compradorId);

                tableHTML += \`
                    <tr>
                        <td><strong>\${viaje.id}</strong></td>
                        <td>\${viaje.conductor || '-'}</td>
                        <td>\${mina ? mina.nombre : 'ID: ' + viaje.minaId}</td>
                        <td>\${comprador ? comprador.nombre : 'ID: ' + viaje.compradorId}</td>
                        <td>\${fechaCargue}</td>
                        <td><span class="status-badge \${statusClass}">\${status}</span></td>
                    </tr>
                \`;
            });

            tableHTML += '</tbody></table>';
            tripsContent.innerHTML = tableHTML;
        }

        document.addEventListener('DOMContentLoaded', loadData);
    </script>
</body>
</html>
  `;
  
  res.setHeader('Content-Type', 'text/html');
  res.send(htmlContent);
});

// Serve PWA icons with correct content-type and cache headers
app.get('*.png', (req, res, next) => {
  const iconPath = path.resolve(req.path.substring(1));
  if (fs.existsSync(iconPath)) {
    res.setHeader('Content-Type', 'image/png');
    // Force refresh for RodMar icons
    if (req.path.includes('rodmar-')) {
      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
      res.setHeader('Pragma', 'no-cache');
      res.setHeader('Expires', '0');
    }
    res.sendFile(iconPath);
  } else {
    next();
  }
});

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  // Initialize database on startup
  await initializeDatabase();
  
  // Add explicit health check endpoints for Replit BEFORE other routes
  app.get('/health', (req, res) => {
    res.status(200).json({ status: 'ok', timestamp: new Date().toISOString() });
  });
  
  // Additional endpoint that Replit might use to detect the app
  app.get('/ping', (req, res) => {
    res.status(200).send('pong');
  });
  
  // Root endpoint verification  
  app.get('/api/status', (req, res) => {
    const port = process.env.PORT || 5000;
    res.status(200).json({ 
      app: 'RodMar PWA', 
      status: 'running',
      port: port,
      env: process.env.NODE_ENV || 'development'
    });
  });
  
  const server = await registerRoutes(app);

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // ALWAYS serve the app on port 5000
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = process.env.PORT || 5000;
  

  
  server.listen(port, "0.0.0.0", () => {
    log(`🚀 RodMar PWA serving on http://0.0.0.0:${port}`);
    log(`🔗 Health check available at http://0.0.0.0:${port}/health`);
  });
})();
