import type { Express } from "express";
import { createServer, type Server } from "http";
import { DatabaseStorage } from "./db-storage";

const storage = new DatabaseStorage();

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Simple auth route that returns a static user
  app.get('/api/auth/user', async (req, res) => {
    res.json({ 
      id: 'main-user', 
      email: 'usuario@rodmar.com', 
      firstName: 'Usuario', 
      lastName: 'Principal' 
    });
  });
  
  // Minas routes
  app.get("/api/minas", async (req, res) => {
    try {
      const minas = await storage.getMinas();
      res.json(minas);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch minas" });
    }
  });

  app.get("/api/minas/:id", async (req, res) => {
    try {
      const minaId = parseInt(req.params.id);
      const mina = await storage.getMina(minaId);
      if (!mina) {
        return res.status(404).json({ error: "Mina not found" });
      }
      res.json(mina);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch mina" });
    }
  });

  app.post("/api/minas", async (req, res) => {
    try {
      const mina = await storage.createMina(req.body);
      res.json(mina);
    } catch (error) {
      res.status(500).json({ error: "Failed to create mina" });
    }
  });

  // Compradores routes
  app.get("/api/compradores", async (req, res) => {
    try {
      const compradores = await storage.getCompradores();
      res.json(compradores);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch compradores" });
    }
  });

  app.get("/api/compradores/:id", async (req, res) => {
    try {
      const compradorId = parseInt(req.params.id);
      const comprador = await storage.getComprador(compradorId);
      if (!comprador) {
        return res.status(404).json({ error: "Comprador not found" });
      }
      res.json(comprador);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch comprador" });
    }
  });

  app.post("/api/compradores", async (req, res) => {
    try {
      const comprador = await storage.createComprador(req.body);
      res.json(comprador);
    } catch (error) {
      res.status(500).json({ error: "Failed to create comprador" });
    }
  });

  // Volqueteros routes
  app.get("/api/volqueteros", async (req, res) => {
    try {
      const volqueteros = await storage.getVolqueteros();
      res.json(volqueteros);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch volqueteros" });
    }
  });

  app.post("/api/volqueteros", async (req, res) => {
    try {
      const volquetero = await storage.createVolquetero(req.body);
      res.json(volquetero);
    } catch (error) {
      res.status(500).json({ error: "Failed to create volquetero" });
    }
  });

  // Viajes routes
  app.get("/api/viajes", async (req, res) => {
    try {
      const viajes = await storage.getViajes();
      res.json(viajes);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch viajes" });
    }
  });

  app.get("/api/viajes/mina/:id", async (req, res) => {
    try {
      const minaId = parseInt(req.params.id);
      const viajes = await storage.getViajesByMina(minaId);
      res.json(viajes);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch viajes for mina" });
    }
  });

  app.get("/api/viajes/comprador/:id", async (req, res) => {
    try {
      const compradorId = parseInt(req.params.id);
      const viajes = await storage.getViajesByComprador(compradorId);
      res.json(viajes);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch viajes for comprador" });
    }
  });

  app.post("/api/viajes", async (req, res) => {
    try {
      const viaje = await storage.createViaje(req.body);
      res.json(viaje);
    } catch (error) {
      res.status(500).json({ error: "Failed to create viaje" });
    }
  });

  app.patch("/api/viajes/:id", async (req, res) => {
    try {
      const viajeId = req.params.id;
      const viaje = await storage.updateViaje(viajeId, req.body);
      res.json(viaje);
    } catch (error) {
      res.status(500).json({ error: "Failed to update viaje" });
    }
  });

  app.delete("/api/viajes/:id", async (req, res) => {
    try {
      const viajeId = req.params.id;
      await storage.deleteViaje(viajeId);
      res.json({ message: "Viaje deleted successfully" });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete viaje" });
    }
  });

  // Transacciones routes
  app.get("/api/transacciones", async (req, res) => {
    try {
      const transacciones = await storage.getTransacciones();
      res.json(transacciones);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch transacciones" });
    }
  });

  app.get("/api/transacciones/socio/:tipoSocio/:socioId", async (req, res) => {
    try {
      const { tipoSocio, socioId } = req.params;
      const transacciones = await storage.getTransaccionesBySocio(tipoSocio, parseInt(socioId));
      res.json(transacciones);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch transacciones for socio" });
    }
  });

  app.post("/api/transacciones", async (req, res) => {
    try {
      const transaccion = await storage.createTransaccion(req.body);
      res.json(transaccion);
    } catch (error) {
      res.status(500).json({ error: "Failed to create transaccion" });
    }
  });

  app.patch("/api/transacciones/:id", async (req, res) => {
    try {
      const transaccionId = parseInt(req.params.id);
      const transaccion = await storage.updateTransaccion(transaccionId, req.body);
      res.json(transaccion);
    } catch (error) {
      res.status(500).json({ error: "Failed to update transaccion" });
    }
  });

  app.delete("/api/transacciones/:id", async (req, res) => {
    try {
      const transaccionId = parseInt(req.params.id);
      await storage.deleteTransaccion(transaccionId);
      res.json({ message: "Transaccion deleted successfully" });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete transaccion" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}