import type { Express, RequestHandler } from "express";
import session from "express-session";
import { storage } from "./storage";

// Store temporal para mantener usuarios autenticados
const temporalAuthStore = new Map<string, any>();

// Inicializar usuario principal automáticamente
function initializeMainUser() {
  const mainUserData = {
    claims: {
      sub: "main_user", 
      email: "usuario@rodmar.com",
      first_name: "Usuario",
      last_name: "Principal"
    },
    expires_at: Math.floor(Date.now() / 1000) + 86400 // 24 horas
  };
  
  // Agregar múltiples patrones de cliente para máxima compatibilidad
  const commonPatterns = [
    '172.31.128.64_Mozilla/5.0 (Win',
    '127.0.0.1_Mozilla/5.0 (X11; Li',
    '172.31.128.64_Mozilla/5.0 (X11',
    '127.0.0.1_Mozilla/5.0 (Win',
    '172.31.128.64_Mozilla/5.0 (Lin', // Linux/Mobile
    '127.0.0.1_Mozilla/5.0 (Lin',     // Linux local
    '172.31.128.64_Mozilla/5.0 (iPh', // iPhone
    '172.31.128.64_Mozilla/5.0 (iPad', // iPad
    '172.31.128.64_Mozilla/5.0 (And', // Android
    '172.31.128.64_Mozilla/5.0 (Mob', // Mobile generic
    'Mozilla/5.0 (Lin',               // Cualquier Linux
    'Mozilla/5.0 (And',               // Cualquier Android
    'Mozilla/5.0 (iPh',               // Cualquier iPhone
    'Mozilla/5.0 (iPad',              // Cualquier iPad
    'Mozilla/5.0 (Mob'                // Cualquier móvil
  ];
  
  commonPatterns.forEach(pattern => {
    temporalAuthStore.set(pattern, mainUserData);
  });
  
  console.log("🔄 Usuario principal inicializado automáticamente para", commonPatterns.length, "patrones");
}

// Simulación temporal de autenticación hasta que el servicio de Replit esté disponible
export function setupFallbackAuth(app: Express) {
  // Inicializar usuario principal automáticamente al configurar
  initializeMainUser();
  
  // Configurar sesiones
  app.use(session({
    secret: process.env.SESSION_SECRET || 'fallback-secret',
    resave: false,
    saveUninitialized: false,
    name: 'rodmar.sid', // Nombre específico para la cookie
    cookie: {
      httpOnly: true,
      secure: false, // False para desarrollo
      sameSite: 'lax', // Permitir cookies cross-site para desarrollo
      maxAge: 24 * 60 * 60 * 1000, // 24 horas
      path: '/' // Asegurar que la cookie sea válida para toda la app
    }
  }));
  
  // Ruta de login que simula el proceso de autenticación
  app.get("/api/login", async (req, res) => {
    // Simular el proceso de login creando una sesión temporal
    req.session = req.session || {};
    // Crear una clave única basada en IP y User-Agent
    const clientKey = `${req.ip}_${req.headers['user-agent']?.substring(0, 50)}`;
    
    const userData = {
      claims: {
        sub: "main_user",
        email: "usuario@rodmar.com",
        first_name: "Usuario",
        last_name: "Principal"
      },
      expires_at: Math.floor(Date.now() / 1000) + 3600 // 1 hora
    };
    
    (req.session as any).user = userData;
    temporalAuthStore.set(clientKey, userData);
    
    console.log("🔑 Cliente registrado:", clientKey.substring(0, 30) + "...");
    
    // Crear o actualizar el usuario en la base de datos
    try {
      await storage.upsertUser({
        id: "main_user",
        email: "usuario@rodmar.com",
        firstName: "Usuario",
        lastName: "Principal",
        profileImageUrl: null
      });
      
      console.log("✅ Usuario autenticado correctamente:", "main_user");
    } catch (error) {
      console.log("❌ Error creating user:", error);
    }
    
    // Forzar que la sesión se guarde antes de redirigir
    req.session.save((err) => {
      if (err) {
        console.log("❌ Error saving session:", err);
        return res.status(500).json({ error: "Error de sesión" });
      }
      
      console.log("✅ Sesión guardada, redirigiendo a /");
      res.redirect("/");
    });
  });

  // Ruta de logout
  app.get("/api/logout", (req, res) => {
    if (req.session) {
      req.session.destroy(() => {
        res.redirect("/");
      });
    } else {
      res.redirect("/");
    }
  });

  // Endpoint de debug para ver estado de sesión
  app.get("/api/debug/session", (req, res) => {
    const session = req.session as any;
    res.json({
      hasSession: !!req.session,
      hasUser: !!(session && session.user),
      userId: session?.user?.claims?.sub || null,
      expires: session?.user?.expires_at || null,
      currentTime: Math.floor(Date.now() / 1000),
      sessionId: req.sessionID || null,
      cookies: req.headers.cookie || null
    });
  });
}

// Middleware de autenticación temporal
export const isFallbackAuthenticated: RequestHandler = async (req, res, next) => {
  const session = req.session as any;
  const clientKey = `${req.ip}_${req.headers['user-agent']?.substring(0, 50)}`;
  
  // AUTENTICACIÓN AUTOMÁTICA PARA TODOS LOS DISPOSITIVOS
  const defaultUser = {
    claims: {
      sub: "main_user",
      email: "usuario@rodmar.com",
      first_name: "Usuario",
      last_name: "Principal"
    },
    expires_at: Math.floor(Date.now() / 1000) + 86400 // 24 horas
  };
  
  // Guardar en store y sesión
  temporalAuthStore.set(clientKey, defaultUser);
  if (session) {
    session.user = defaultUser;
  }
  
  console.log("✅ Auth automática para dispositivo:", clientKey.substring(0, 30) + "...");
  
  // Asignar usuario y continuar
  req.user = defaultUser;
  next();
};